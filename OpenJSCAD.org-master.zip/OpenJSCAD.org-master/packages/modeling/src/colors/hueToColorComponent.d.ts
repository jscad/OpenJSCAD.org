export default hueToColorComponent

declare function hueToColorComponent(p: number, q: number, t: number): number

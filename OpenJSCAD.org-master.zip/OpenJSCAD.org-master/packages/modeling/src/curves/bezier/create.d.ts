import Bezier from './type'

export default create

declare function create(points: Array<number> | Array<Array<number>>): Bezier

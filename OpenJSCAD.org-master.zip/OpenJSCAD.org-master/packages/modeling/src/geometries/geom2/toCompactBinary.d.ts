import Geom2 from './type'

export default toCompactBinary

declare function toCompactBinary(geom: Geom2): Float32Array

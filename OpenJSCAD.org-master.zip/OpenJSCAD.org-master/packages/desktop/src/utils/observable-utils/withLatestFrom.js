const withLatestFrom = (streams, fn) => {
  console.log('foo', streams)
}
module.exports = withLatestFrom

// const path = require('path')
// experimental
// const {astFromSource, csgTree} = require('./core/code-analysis/index')
// const ast = astFromSource(mainScriptAsText)
// const prevAst = astFromSource(state.design.script)
/* console.log('ast', ast)

      const differences = findByPredicate(isDifference, node => node, ast)
      console.log('differences', differences)

      const cubes = findByPredicate(isCube, node => node, ast)
      console.log('cubes', cubes)

      const spheres = findByPredicate(isSphere, node => node, ast)
      console.log('spheres', spheres) */
// console.log('previous ast')
// csgTree(prevAst)
// console.log('current ast', ast)
// csgTree(ast)

module.exports = {
  registerAllExtensions: require('./registerExtensions').registerAllExtensions,
  unRegisterAllExtensions: require('./registerExtensions').unRegisterAllExtensions
}

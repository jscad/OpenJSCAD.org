const inchMM = (1 / 0.039370) // used for scaling AMF (inch) to coordinates (mm)

module.exports = {
  inchMM
}

module.exports = function () {
  this.argname
  this.argexpr
}

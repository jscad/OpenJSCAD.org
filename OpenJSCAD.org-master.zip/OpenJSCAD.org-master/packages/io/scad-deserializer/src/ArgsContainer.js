module.exports = function () {
  this.argnames = []
  this.argexpr = []
}

# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.3.14](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.13...@jscad/dxf-deserializer@2.3.14) (2022-04-03)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.13](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.12...@jscad/dxf-deserializer@2.3.13) (2022-04-03)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.12](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.11...@jscad/dxf-deserializer@2.3.12) (2022-03-13)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.11](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.10...@jscad/dxf-deserializer@2.3.11) (2022-03-06)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.10](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.9...@jscad/dxf-deserializer@2.3.10) (2022-02-19)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.9](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.8...@jscad/dxf-deserializer@2.3.9) (2021-12-26)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.8](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.7...@jscad/dxf-deserializer@2.3.8) (2021-12-11)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.7](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.6...@jscad/dxf-deserializer@2.3.7) (2021-11-07)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.6](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.5...@jscad/dxf-deserializer@2.3.6) (2021-10-17)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.5](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.4...@jscad/dxf-deserializer@2.3.5) (2021-10-04)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.4](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.3...@jscad/dxf-deserializer@2.3.4) (2021-09-27)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.3](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.2...@jscad/dxf-deserializer@2.3.3) (2021-09-09)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.2](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.1...@jscad/dxf-deserializer@2.3.2) (2021-06-20)

**Note:** Version bump only for package @jscad/dxf-deserializer





## [2.3.1](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.3.0...@jscad/dxf-deserializer@2.3.1) (2021-06-11)


### Bug Fixes

* **dxf-deserializer:** corrected conversion of color values found on entities ([6c974aa](https://github.com/jscad/OpenJSCAD.org/commit/6c974aa54d736a29045d2ffbe24488b064680a5b))





# [2.3.0](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.2.0...@jscad/dxf-deserializer@2.3.0) (2021-06-01)


### Features

* **modeling:** rework math objects to conform with gl-matrix ([#804](https://github.com/jscad/OpenJSCAD.org/issues/804)) ([2e52f10](https://github.com/jscad/OpenJSCAD.org/commit/2e52f104e569f2bb7dd9e1be3d238f471f4d3dfa))





# [2.2.0](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.0...@jscad/dxf-deserializer@2.2.0) (2021-04-20)


### Bug Fixes

* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))
* **dxf-deserializer:** support for colors in dxf serializer ([#684](https://github.com/jscad/OpenJSCAD.org/issues/684)) ([2b89a3a](https://github.com/jscad/OpenJSCAD.org/commit/2b89a3a7c4dde177ed93769d96522319954188df))


### Features

* **modeling:** V2 : rename option to align and center ([#775](https://github.com/jscad/OpenJSCAD.org/issues/775)) ([c5b0f48](https://github.com/jscad/OpenJSCAD.org/commit/c5b0f48bbd980b59876d73b673a0e3bef44d2b30))





# [2.1.0](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.0...@jscad/dxf-deserializer@2.1.0) (2021-04-15)


### Bug Fixes

* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/OpenJSCAD.org/issues/705)) ([62017a4](https://github.com/jscad/OpenJSCAD.org/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))
* **dxf-deserializer:** support for colors in dxf serializer ([#684](https://github.com/jscad/OpenJSCAD.org/issues/684)) ([2b89a3a](https://github.com/jscad/OpenJSCAD.org/commit/2b89a3a7c4dde177ed93769d96522319954188df))


### Features

* **modeling:** V2 : rename option to align and center ([#775](https://github.com/jscad/OpenJSCAD.org/issues/775)) ([c5b0f48](https://github.com/jscad/OpenJSCAD.org/commit/c5b0f48bbd980b59876d73b673a0e3bef44d2b30))





# [2.0.0](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.11...@jscad/dxf-deserializer@2.0.0) (2021-04-12)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.11](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.10...@jscad/dxf-deserializer@2.0.0-alpha.11) (2021-03-07)


### Features

* **modeling:** V2 : rename option to align and center ([#775](https://github.com/jscad/OpenJSCAD.org/issues/775)) ([c5b0f48](https://github.com/jscad/OpenJSCAD.org/commit/c5b0f48bbd980b59876d73b673a0e3bef44d2b30))





# [2.0.0-alpha.10](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.9...@jscad/dxf-deserializer@2.0.0-alpha.10) (2021-02-07)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.9](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.8...@jscad/dxf-deserializer@2.0.0-alpha.9) (2021-01-02)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.8](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.7...@jscad/dxf-deserializer@2.0.0-alpha.8) (2020-12-04)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.7](https://github.com/jscad/OpenJSCAD.org/compare/@jscad/dxf-deserializer@2.0.0-alpha.6...@jscad/dxf-deserializer@2.0.0-alpha.7) (2020-11-07)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.6](https://github.com/jscad/compare/@jscad/dxf-deserializer@2.0.0-alpha.5...@jscad/dxf-deserializer@2.0.0-alpha.6) (2020-10-11)


### Bug Fixes

* **all:** V2 : several fixes for modeling ([#705](https://github.com/jscad/issues/705)) ([62017a4](https://github.com/jscad/commit/62017a41214169d6e000f1e0c11aaefdd68e1097))





# [2.0.0-alpha.5](https://github.com/jscad/compare/@jscad/dxf-deserializer@2.0.0-alpha.4...@jscad/dxf-deserializer@2.0.0-alpha.5) (2020-09-29)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.4](https://github.com/jscad/compare/@jscad/dxf-deserializer@2.0.0-alpha.3...@jscad/dxf-deserializer@2.0.0-alpha.4) (2020-09-28)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.3](https://github.com/jscad/compare/@jscad/dxf-deserializer@2.0.0-alpha.2...@jscad/dxf-deserializer@2.0.0-alpha.3) (2020-09-19)


### Bug Fixes

* **dxf-deserializer:** support for colors in dxf serializer ([#684](https://github.com/jscad/issues/684)) ([2b89a3a](https://github.com/jscad/commit/2b89a3a7c4dde177ed93769d96522319954188df))





# [2.0.0-alpha.2](https://github.com/jscad/compare/@jscad/dxf-deserializer@2.0.0-alpha.1...@jscad/dxf-deserializer@2.0.0-alpha.2) (2020-09-08)

**Note:** Version bump only for package @jscad/dxf-deserializer





# [2.0.0-alpha.1](https://github.com/jscad/compare/@jscad/dxf-deserializer@2.0.0-alpha.0...@jscad/dxf-deserializer@2.0.0-alpha.1) (2020-08-19)

**Note:** Version bump only for package @jscad/dxf-deserializer





# 2.0.0-alpha.0 (2020-08-13)


### Bug Fixes

* **colors:** colorize is now immutable & returns new geometries ([#566](https://github.com/jscad/issues/566)) ([916824c](https://github.com/jscad/commit/916824c63a0bf8896d1b6f85a82b129a013bec58))
* **dxf-deserializer:** corrected translation of lwpolylines & coding style update([#519](https://github.com/jscad/issues/519)) ([6bb2b38](https://github.com/jscad/commit/6bb2b3878d6b9e4f62fc741801ec9f0fad17575d))
* **dxf-deserializer:** corrected translate() to provide V2 require and export ([#496](https://github.com/jscad/issues/496)) ([9155a36](https://github.com/jscad/commit/9155a367b86046aa21992d7858fe0d54116f9975))


### Features

* **dxf-deserializer:** updated for V2 (#465)
* **io:** change api to deserialize(options, source)





<a name="0.1.2"></a>
## [0.1.2](https://github.com/jscad/io/compare/@jscad/dxf-deserializer@0.1.1...@jscad/dxf-deserializer@0.1.2) (2018-11-22)




**Note:** Version bump only for package @jscad/dxf-deserializer

<a name="0.1.1"></a>
## [0.1.1](https://github.com/jscad/io/compare/@jscad/dxf-deserializer@0.1.0...@jscad/dxf-deserializer@0.1.1) (2018-05-24)


### Bug Fixes

* **dxf-deserializer:** fix layers/ labels ([#65](https://github.com/jscad/io/issues/65)) ([2804e3b](https://github.com/jscad/io/commit/2804e3b))




<a name="0.1.0"></a>
# 0.1.0 (2018-02-24)


### Features

* **DXF Deserializer:** Adds dxf deserializer and all associated code ([ae4a6c0](https://github.com/jscad/io/commit/ae4a6c0)), closes [#10](https://github.com/jscad/io/issues/10)
